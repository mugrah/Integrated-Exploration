#include <fstream>
#include <iostream>

#include "frontiers.h"

#define A 0
#define B 1
#define D 1

typedef struct goalCell{
  int x;
  int y;
  int valid;
}ff;

goalCell goal_cell;


void chooseGoal(std::vector<frontier_position> &frontier_vector, std::string robot_topic){

    double f_max = 0;
    double f;

    goal_cell.valid=0;

    std::ofstream myfile;
    std::string filename = "/home/rcolares/catkin_ws/src/ros-pioneer3at/maps/function"+robot_topic+".txt";
    myfile.open (filename.c_str(),  std::ios::out);// | std::ios::app );

    for(int i=0; i<frontier_vector.size(); i++){
        f = A*frontier_vector[i].window + B*frontier_vector[i].wave - D*frontier_vector[i].neg_wave;
        myfile<<f<<" "<<A*frontier_vector[i].window<<" "<<B*frontier_vector[i].wave<<" "<<D*frontier_vector[i].neg_wave<<std::endl;

        if(f > f_max){
            f_max = f;
            goal_cell.valid=1;
            goal_cell.x = frontier_vector[i].x_mean;
            goal_cell.y = frontier_vector[i].y_mean;
        }

    }
    myfile.close();

}




