#include <nav_msgs/GetMap.h>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <iostream>

#include "gmapping/occMap.h"
#include "frontiers.h"

void mapTransform(gmapping::occMap map,  int width, int height, int **real_map, double **mapa, double **occ_real_map, double **windows, double **neg_wave, double **wave_map){

  for(int l=0;l<height;l++){
    for(int k=0;k<width;k++){
      int t = (height - l -1)*width +k;
      real_map[l][k] = map.map.data[t];
      windows[l][k]=0.0;
      occ_real_map[l][k] = map.data[t];
      if(real_map[l][k] == +100)
          mapa[l][k] = 1;
      else
          mapa[l][k]=-1;

      if(real_map[l][k] == 0){
          wave_map[l][k] = 999999;
          neg_wave[l][k] = 999999;
      }else{
          wave_map[l][k] = -1;
          neg_wave[l][k] = -1;
      }

    }
  }
}




int check_if_frontier(int **real_map, int j, int k){
    int flag = 0;
    if(real_map[j-1][k-1] == -1)
        flag++;
    if(real_map[j-1][k]== -1)
        flag++;
    if(real_map[j-1][k+1] == -1)
        flag++;
    if(real_map[j][k-1] == -1)
        flag++;
    if(real_map[j][k+1] == -1)
        flag++;
    if(real_map[j+1][k-1] == -1)
        flag++;
    if(real_map[j+1][k] == -1)
        flag++;
    if(real_map[j+1][k+1] == -1)
        flag++;
    if(real_map[j-1][k-1] == +100)
        return 0;
    if(real_map[j-1][k]== +100)
        return 0;
    if(real_map[j-1][k+1] == +100)
        return 0;
    if(real_map[j][k-1] == +100)
        return 0;
    if(real_map[j][k+1] == +100)
        return 0;
    if(real_map[j+1][k-1] == +100)
        return 0;
    if(real_map[j+1][k] == +100)
        return 0;
    if(real_map[j+1][k+1] == +100)
        return 0;
    return flag;
}

void createFrontiers(int width, int height, int **real_map, double **mapa, std::vector<frontier_position> &frontier_vector){

    int flag;

    frontier_vector.clear();

    for(int i=1;i<height-1;i++){
        for(int e=1;e<width-1;e++){
            if(real_map[i][e] ==0){
                if(check_if_frontier(real_map, i, e)){
                    mapa[i][e]=0;

                    if(frontier_vector.size()==0){
                        frontier_position aux;
                        aux.num = 1;
                        aux.x.push_back(e);
                        aux.y.push_back(i);
                        frontier_vector.push_back(aux);
                    }else{
                        flag=0;
                        for(int k = 0; k < frontier_vector.size(); k++){
                            for(int j = 0; j < frontier_vector[k].x.size(); j++){
                                float dist = sqrt((frontier_vector[k].y[j]-i)*(frontier_vector[k].y[j]-i) + (frontier_vector[k].x[j]-e)*(frontier_vector[k].x[j]-e));
                                if(dist<=7){
                                    frontier_vector[k].num+=1;
                                    frontier_vector[k].x.push_back(e);
                                    frontier_vector[k].y.push_back(i);
                                    flag=1;
                                    break;
                                }
                            }
                            if(flag==1)
                                break;
                        }
                        if(flag==0){
                            frontier_position aux;
                            aux.num = 1;
                            aux.x.push_back(e);
                            aux.y.push_back(i);
                            frontier_vector.push_back(aux);
                        }
                    }
                }
            }
        }
    }

    int j=0;
    while(j<frontier_vector.size()){
        if(frontier_vector[j].num<30)
            frontier_vector.erase(frontier_vector.begin()+j);
        else
            j++;
    }

    int dist;
    int mindist;
    for(int k=0;k<frontier_vector.size();k++){

        mindist=-1;

        for(int i = 0; i<frontier_vector[k].x.size(); i++){
            dist = 0;

            for(int e = 1; e<frontier_vector[k].x.size(); e++){
                dist += sqrt((frontier_vector[k].x[i] - frontier_vector[k].x[e])*(frontier_vector[k].x[i] - frontier_vector[k].x[e]) + (frontier_vector[k].y[i] - frontier_vector[k].y[e])*(frontier_vector[k].y[i] - frontier_vector[k].y[e]));
            }

            if(mindist==-1 || dist<mindist){
                mindist = dist;
                frontier_vector[k].min_dist = i;
                frontier_vector[k].x_mean = frontier_vector[k].x[i];
                frontier_vector[k].y_mean = frontier_vector[k].y[i];
            }
        }
    }
}
